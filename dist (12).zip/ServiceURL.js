var ServiceURL = {
    Adminapi:'https://o2o.liqunshop.com/adminwebapi',          /* 后台 */
    Frame:'https://o2o.liqunshop.com/framewebapi'        /* 权限 */
}
/* var ImageURL={
    ImageURL:'http://images.liqunshop.com/'
  } */